echo "- Mounting Magisk to system..."
cd /sbin/magiskimg
DIRS=$(find * -type d)
for dir in $DIRS; do
  mkdir /$dir
done

FILES=$(find * -type f)
for file in $FILES; do
  ln -s $file /$file
done

AARCH=$(getprop ro.product.cpu.abi);

SYMLINKS="
/sbin/magisk
/sbin/su
/sbin/resetprop
/sbin/magiskhide
"

if [ "$AARCH" == "arm64-v8a" ]; then
 for sym in $SYMLINKS; do
  ln -s /sbin/magisk64 $sym
 done
elif [ "$AARCH" == "armeabi-v7a" ]; then
 for sym in $SYMLINKS; do
  ln -s /sbin/magisk32 $sym
 done
else
 echo "! Wrong CPU ABI: $AARCH"
 touch error
fi

IGNORE_PLACE=false


echo "- Magisk on VMOS Pro by HuskyDG"
echo "- Preparing for Magisk, need root access"
printf "- Root access: "
pm install magisk.apk  &>/dev/null && Surep=1 
if [ "$Surep" == "1" ]; then
  echo "GRANTED"
  echo "- Installing Magisk boot..."
  chmod -R 777 magiskimg
  cp magiskimg /sbin/magiskimg
  sh mount.sh
  printf "- Launch Magisk daemon..."
  magisk --daemon && MDaemon=1
  if [ "$MDaemon" == "1" ]; then
    echo "SUCCESS"
  else
    echo "FAILED"
    touch error
  fi
else
  echo "NOT GRANTED"
  touch error
fi

chmod 777 system/etc/init/magisk.rc

if [ -f error ]; then
IGNORE_PLACE=true
fi